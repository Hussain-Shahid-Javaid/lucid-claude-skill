"""Optional HTTP service (FastAPI)."""
